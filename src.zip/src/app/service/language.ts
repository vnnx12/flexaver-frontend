import { ENG } from "./ENG";
import { TH } from "./TH";

export const language = {
    ENG: ENG,
    TH: TH,
}