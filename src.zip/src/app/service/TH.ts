



const thnavbar = [{
    homepage: "หน้าหลัก",
    favpage: "รายการที่ชื่นชอบ",
    libpage: "คลังของฉัน"
}]

const landingpageth = [{
    title: "ปฏิวัติการสื่อสารด้วย Flex Messages",
    body: "เลย์เอาต์แบบไดนามิกที่สามารถปรับแต่งได้เพื่อดึงดูดผู้ใช้งานของ <br> คุณ ยกระดับเกมการรับส่งข้อความของคุณวันนี้!",
    but1: "คาเฟ่/ร้านอาหาร",
    but2: "การศึกษา",
    but3: "ความบันเทิง",
    but4: "โรงแรม",
    but5: "ร้านค้า",
    but6: "การเงิน",
    bubble: "Bubble เป็นการแสดงผลข้อความที่สามารถบรรจุได้ทั้งข้อความ, รูปภาพ และปุ่มกด ช่วยจัดเรียงและนำเสนอข้อมูลให้ออกมาน่าสนใจ",
    flex: "สามารถเพิ่มยอด engagement ปรับเปลี่ยนรูปการนำเสนอในแบบของคุณ<br> และมีเวิร์กโฟลว์ที่คล่องตัว <br> ซึ่งเป็นประโยชน์ต่อธุรกิจโดยผลักดันปฏิสัมพันธ์กับลูกค้า ปรับปรุงการสื่อสาร <br> และปรับกระบวนการให้เหมาะสม"
    
    
}]

export const TH= {
    navbar: thnavbar[0],
    favpage: thnavbar[1],
    libpage: thnavbar[2],
    landingpage: landingpageth[0],
    landingpage2: landingpageth[1],
    button1: landingpageth[2],
    button2: landingpageth[3],
    button3: landingpageth[4],
    button4: landingpageth[5],
    button5: landingpageth[6],
    button6: landingpageth[7],
    
}





